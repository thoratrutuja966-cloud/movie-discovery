from datetime import date
from django.core.paginator import Paginator
from django.db.models import Count, F, Min, Q
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from .models import BookingHistory, Genre, Movie, MovieView, Showtime, Theater

SORTS = {"popular": "-popularity", "newest": "-release_date", "rating": "-rating", "price": "showtimes__ticket_price"}

def movie_list(request):
    params = request.GET
    movies = Movie.objects.all().prefetch_related("genres").annotate(
        min_price=Min("showtimes__ticket_price"),
        next_show=Min("showtimes__starts_at", filter=Q(showtimes__starts_at__gte=timezone.now())),
        cities_count=Count("showtimes__theater__city", distinct=True),
    ).distinct()
    query = params.get("q", "").strip()
    if query: movies = movies.filter(title__icontains=query)
    if params.get("genre"): movies = movies.filter(genres__slug=params["genre"])
    if params.get("language"): movies = movies.filter(language=params["language"])
    if params.get("city"): movies = movies.filter(showtimes__theater__city__iexact=params["city"])
    if params.get("theater"): movies = movies.filter(showtimes__theater_id=params["theater"])
    if params.get("date"):
        try: movies = movies.filter(release_date__gte=date.fromisoformat(params["date"]))
        except ValueError: pass
    if params.get("min_rating"):
        try: movies = movies.filter(rating__gte=float(params["min_rating"]))
        except ValueError: pass
    if params.get("show_date"):
        try:
            show_day = date.fromisoformat(params["show_date"])
            movies = movies.filter(showtimes__starts_at__date=show_day)
        except ValueError: pass
    sort = params.get("sort", "popular")
    if sort == "price": movies = movies.order_by("min_price", "title")
    else: movies = movies.order_by(SORTS.get(sort, SORTS["popular"]), "title")
    # Count is applied to the already filtered queryset, so the live result total matches the cards.
    match_count = movies.count()
    page = Paginator(movies, 9).get_page(params.get("page"))
    recommendations = Movie.objects.none()
    if request.user.is_authenticated:
        watched_ids = MovieView.objects.filter(user=request.user).order_by().values("movie_id")
        booked_ids = BookingHistory.objects.filter(
            user=request.user, status=BookingHistory.Status.CONFIRMED
        ).order_by().values("movie_id")
        interacted_ids = watched_ids.union(booked_ids)
        favorite_genres = Genre.objects.annotate(
            view_score=Count("movies__view_events", filter=Q(movies__view_events__user=request.user), distinct=True),
            booking_score=Count("movies__booking_history", filter=Q(movies__booking_history__user=request.user, movies__booking_history__status=BookingHistory.Status.CONFIRMED), distinct=True),
        ).annotate(score=F("view_score") + 2 * F("booking_score")).filter(score__gt=0).order_by("-score", "name").values("id")[:3]
        recommendations = Movie.objects.exclude(pk__in=interacted_ids).filter(genres__in=favorite_genres).annotate(
            shared=Count("genres", distinct=True),
        ).order_by("-shared", "-popularity").distinct()[:4]
    return render(request, "discovery/movie_list.html", {"movies": page, "page_obj": page, "match_count": match_count,
        "featured_movies": Movie.objects.order_by("-popularity", "title")[:3],
        "genres": Genre.objects.order_by("name"), "languages": Movie.objects.order_by("language").values_list("language", flat=True).distinct(),
        "cities": Theater.objects.order_by("city").values_list("city", flat=True).distinct(), "theaters": Theater.objects.order_by("name"),
        "recommendations": recommendations, "filters": params, "sorts": [("popular", "Popularity"), ("newest", "Newest releases"), ("rating", "Top rated"), ("price", "Ticket price")], "today": timezone.localdate()} )

def movie_detail(request, pk):
    movie = get_object_or_404(Movie.objects.prefetch_related("genres"), pk=pk)
    if request.user.is_authenticated:
        MovieView.objects.create(user=request.user, movie=movie)
    showtimes = Showtime.objects.filter(movie=movie, starts_at__gte=timezone.now()).select_related("theater").order_by("starts_at")
    similar = Movie.objects.filter(genres__in=movie.genres.all()).exclude(pk=movie.pk).distinct().order_by("-popularity")[:4]
    return render(request, "discovery/movie_detail.html", {"movie": movie, "showtimes": showtimes, "similar": similar})
