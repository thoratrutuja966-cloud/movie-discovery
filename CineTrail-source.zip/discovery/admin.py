from django.contrib import admin
from .models import BookingHistory, Genre, Movie, MovieView, Showtime, Theater

admin.site.site_header = "CineTrail Administration"
admin.site.site_title = "CineTrail Admin"
admin.site.index_title = "Manage movies and showtimes"

@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ("title", "language", "release_date", "rating", "popularity")
    list_filter = ("language", "genres")
    search_fields = ("title", "synopsis")
    filter_horizontal = ("genres",)

admin.site.register((Genre, Theater, Showtime, MovieView, BookingHistory))
